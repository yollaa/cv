<nav class="navbar navbar-expand-md  fixed-top maine-menu">
    <div class="container">
      <button class="navbar-toggler ml-auto" data-target="#my-nav" onclick="myFunction(this)" data-toggle="collapse"> <span class="bar1"></span> <span class="bar2"></span> <span class="bar3"></span> </button>
      <div id="my-nav" class="collapse navbar-collapse">
        <ul class="navbar-nav mx-auto">
          <li class="nav-item active"> <a class="nav-link" href="#">Home</a> </li>
          <li class="nav-item"> <a class="nav-link" href="#about" tabindex="-1" aria-disabled="true">Biodata</a></li>
          <li class="nav-item"> <a class="nav-link" href="#activity" tabindex="-1" aria-disabled="true">Pendidikan</a></li>
          <li class="nav-item"> <a class="nav-link" href="#portfolio" tabindex="-1" aria-disabled="true">Portfolio</a></li>
		  <li class="nav-item"> <a class="nav-link" href="#fh5co-skills" tabindex="-1" aria-disabled="true">Skill</a></li>
          <li class="nav-item"> <a class="nav-link" href="#testimonial" tabindex="-1" aria-disabled="true">Pengalaman</a></li>
          <li class="nav-item"> <a class="nav-link" href="http://my.jayagame.xyz/wp/" tabindex="-1" aria-disabled="true">Blog</a></li>
		  <li class="nav-item"> <a class="nav-link" href="admin" tabindex="-1" aria-disabled="true">Admin</a></li>
          <li class="nav-item"> <a class="nav-link" href="#contact" tabindex="-1" aria-disabled="true">Kontak</a></li>
        </ul>
      </div>
    </div>
  </nav>