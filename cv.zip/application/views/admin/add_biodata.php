<!-- modal input -->
<?php
include 'kode_biodata.php';
?>
<div id="myModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Tambah Biodata Baru</h4>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('master/biodata/add')?>" method="post" enctype="multipart/form-data">
					<div class="form-group">
						<label>Id Biodata</label>
						<input name="id_biodata" readonly="" value="<?php echo $kodebiodata; ?>" type="text" class="form-control">
					</div>
					<div class="form-group">
						<label>Profesi</label>
						<input name="profesi" type="text" class="form-control" placeholder="Profesi Anda">
					</div>
					<div class="form-group">
						<label>Nama</label>
						<input name="nama" type="text" class="form-control" placeholder="Nama Anda">
					</div>	
					<div class="form-group">
						<label>Jenis Kelamin</label>
						<input name="jk" type="text" class="form-control" placeholder="Jenis Kelamin..">
					</div>	
					<div class="form-group">
						<label>Tempat Tanggal Lahir</label>
						<input name="ttl" type="text" class="form-control" placeholder="Tempat, Tanggal Lahir..">
					</div>
					<div class="form-group">
						<label>Alamat</label>
						<input name="alamat" type="text" class="form-control" placeholder="Alamat Anda">
					</div>
					<div class="form-group">
						<label>Agama</label>
						<input name="agama" type="text" class="form-control" placeholder="Agama Anda">
					</div>	
					<div class="form-group">
						<label>Status</label>
						<input name="status" type="text" class="form-control" placeholder="Status Anda">
					</div>	
					<div class="form-group">
						<label>Foto</label>
						<input name="foto" type="file" class="form-control" placeholder="Masukan Foto">
					</div>	
					<div class="form-group">
						<label>Resume</label>
						<input name="resume" type="text" class="form-control" placeholder="Resume..">
					</div>	
					<div class="form-group">
						<label>Keterangan</label>
						<input name="keterangan" type="text" class="form-control" placeholder="Keterangan..">
					</div>						

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
					<input type="submit" class="btn btn-primary" value="Simpan">
				</div>
			</form>
		</div>
	</div>
</div>