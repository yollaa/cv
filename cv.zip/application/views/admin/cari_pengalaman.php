<?php 
$cari=$_GET['cari'];
header("location:pengalaman.php?cari=$cari");
?>