<?php 
$cari=$_GET['cari'];
header("location:pendidikan.php?cari=$cari");
?>