
<?php 
include 'config.php';
$id=$_POST['id_biodata'];
$profesi=$_POST['profesi'];
$jk=$_POST['jk'];
$ttl=$_POST['ttl'];
$alamat=$_POST['alamat'];
$agama=$_POST['agama'];
$status=$_POST['status'];
$foto = $_FILES['foto']['name'];
$foto_lama = $_POST['foto_lama'];
$tmp = $_FILES['foto']['tmp_name']
$resume=$_POST['resume'];
$keterangan=$_POST['keterangan'];

// move_uploaded_file($_FILES['foto']['tmp_name'], "foto/".$_FILES['foto']['name'])or die();
// 	mysql_query("update admin set foto='$foto' where uname='$user'");

  
$ex = explode('.',$foto);
$nama_baru = 'foto_'.time().'.'.strtolower($ex[1]);
 
$daftar_extensi = ['jpg','png','jpeg'];
$extensi = strtolower(end($ex));
 
if (in_array($extensi,$daftar_extensi) === true) {
  $pindah = move_uploaded_file($tmp,'foto/'.$nama_baru);
  $query = $koneksi->query("UPDATE tb_foto set profesi='$profesi', jk='$jk', ttl='$ttl', alamat='$alamat', agama='$agama', status='$status', foto='$foto', resume='$resume', keterangan='$keterangan' where id_biodata='$id'");
  if (file_exists('foto/'.$foto_lama)) {
    unlink('foto/'.$foto_lama);
  }
  header('location:biodata.php');
}else{
  echo "Type File Salah !!! <a href='biodata.php'> << Kembali</a>";
}




//mysqli_query($koneksi,"update biodata set profesi='$profesi', jk='$jk', ttl='$ttl', alamat='$alamat', agama='$agama', status='$status', foto='$foto', resume='$resume', keterangan='$keterangan' where id_biodata='$id'");
header("location:biodata.php");

 ?>