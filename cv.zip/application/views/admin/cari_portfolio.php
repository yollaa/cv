<?php 
$cari=$_GET['cari'];
header("location:portfolio.php?cari=$cari");
?>