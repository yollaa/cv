<?php $this->load->view("_partial/admin/header.php") ?>
<h3><span class="glyphicon glyphicon-user"></span>  Edit Biodata</h3>
<a class="btn" href="<?= base_url('admin/biodata') ?>"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>
<?php
//$id_brg=mysqli_real_escape_string($koneksi,$_GET['id_biodata']);
//$det=mysqli_query($koneksi,"select * from biodata where id_biodata='$id_brg'")or die(mysql_error());
//while($d=mysqli_fetch_array($det)){
?>					
	<form action="<?=base_url('master/biodata/edit')?>" method="post" enctype="multipart/form-data">
		<table class="table">
			<tr>
				<td>Id Biodata</td>
				<td><input type="text" class="form-control" readonly="" name="id_biodata" value="<?= $biodata->id_biodata ?>"></td>
			</tr>
			<tr>
				<td>Profesi</td>
				<td><input type="text" class="form-control" name="profesi" value="<?= $biodata->profesi ?>"></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" class="form-control" name="nama" value="<?= $biodata->nama ?>"></td>
			</tr>
			<tr>
				<td>Jenis Kelamin</td>
				<td><input type="text" class="form-control" name="jk" value="<?= $biodata->jk ?>"></td>
			</tr>
			<tr>
				<td>Tempat Tanggal Lahir</td>
				<td><input type="text" class="form-control" name="ttl" value="<?= $biodata->ttl ?>"></td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td><input type="text" class="form-control" name="alamat" value="<?= $biodata->alamat ?>"></td>
			</tr>
			<tr>
				<td>Agama</td>
				<td><input type="text" class="form-control" name="agama" value="<?= $biodata->agama ?>"></td>
			</tr>
			<tr>
				<td>Status</td>
				<td><input type="text" class="form-control" name="status" value="<?= $biodata->status ?>"></td>
			</tr>
			<tr>
				<td>Foto</td>
				<td><input type="file" class="form-control" name="foto" value="<?= $biodata->foto ?>"></td>
			</tr>
			<tr>
				<td>Resume</td>
				<td><input type="text" class="form-control" name="resume" value="<?= $biodata->resume ?>"></td>
			</tr>
			<tr>
				<td>Keterangan</td>
				<td><input type="text" class="form-control" name="keterangan" value="<?= $biodata->keterangan ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" class="btn btn-info" value="Simpan"></td>
			</tr>
		</table>
	</form>
<?php $this->load->view("_partial/admin/footer.php") ?>