<?php 
$cari=$_GET['cari'];
header("location:biodata.php?cari=$cari");
?>